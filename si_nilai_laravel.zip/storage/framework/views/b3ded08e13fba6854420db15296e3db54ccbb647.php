<?php $__env->startSection('content'); ?>
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="row">
            <div class="col-xl-12 mb-4">
                <h6>Pengaturan <span class="fas fa-arrow-right"></span> Mapel</h6>

                <div class="messages"></div>

                <div class="card mt-2">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-12">
                                <form id="filter-class">
                                    <div class="form-group mb-3">
                                        <label for="">
                                            Kelas
                                        </label>
                                        <select name="class_id" class="form-control" style="width: 30%">
                                            <option value="">Pilih Kelas</option>
                                            <?php $__currentLoopData = $class; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($c->id); ?>"><?php echo e($c->nama_rombel); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <button type="submit" class="btn btn-success filter">
                                        Filter
                                    </button>
                                </form>
                            </div>
                        </div>
                        <div class="mt-3">
                            <div id="gur-maping-mapel" style="display: none;"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('pageTitle', 'Menentukan Guru Mapel'); ?>

<?php echo $__env->make('dash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\si_nilai_laravel\resources\views/set_mapel.blade.php ENDPATH**/ ?>
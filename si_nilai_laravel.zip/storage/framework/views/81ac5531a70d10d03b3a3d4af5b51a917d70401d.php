<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="card mt-2">
    <div class="card-header text-white bg-dark">
        <?php echo e($m->judul); ?>

        <br><br>
        <em class="fas fa-calendar"></em> <?php echo e(date('d-m-Y H:i:s', strtotime($m->create_at))); ?> <em
            class="fas fa-user"></em> <?php echo e($m->user->personalData->nama); ?>

    </div>
    <div class="card-body">
        <p class="mt-3">
            <?php echo $m->isi; ?>

        </p>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH F:\si_nilai_laravel\resources\views/pesan_in_dash.blade.php ENDPATH**/ ?>
<div class="row">
    <div class="col-md-12 mb-2">
        <div class="card">
            <div class="card-body">
                <div class="row mb-3">
                    <div class="col-md-2">
                        <label for="">Nama</label>
                    </div>
                    <div class="col-md-6">
                        <input type="text" class="form-control" value="<?php echo e($s->nama); ?>" readonly>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-2">
                        <label for="">Kelas</label>
                    </div>
                    <div class="col-md-6">
                        <input type="text" class="form-control" value="<?php echo e($k->nama_rombel); ?>" readonly>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-2">
                        <label for="">Tahun Ajaran</label>
                    </div>
                    <div class="col-md-6">
                        <input type="text" class="form-control" value="<?php echo e($tahun_ajaran); ?> <?php echo e($smt); ?> (<?php echo e($semester); ?>)" readonly>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-12 mb-2">
        <div class="card">
            <div class="card-body">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Mata Pelajaran</th>
                            <th>KKM</th>
                            <th>P</th>
                            <th>K</th>
                            <th>NA</th>
                            <th>Predikat</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $mp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $nilaiMapel = $nilai->where('mapel_id', $m->id)->first();
                                    $pengetahuan = $nilaiMapel ? $nilaiMapel->nilai_pengetahuan : 0;
                                    $keterampilan = $nilaiMapel ? $nilaiMapel->nilai_keterampilan : 0;
                                    $nilaiAkhir = ($pengetahuan + $keterampilan) / 2;
                                    $predikat = $nilaiAkhir >= $m->kkm + 20 ? 'A+' :
                                                ($nilaiAkhir >= $m->kkm + 10 ? 'A' :
                                                ($nilaiAkhir >= $m->kkm ? 'B' :
                                                ($nilaiAkhir >= $m->kkm - 10 ? 'C' : 'D')));
                                ?>
                            <tr>
                                <td><?php echo e($m->nama_mapel); ?></td>
                                <td><?php echo e($m->kkm); ?></td>
                                <td><?php echo e($pengetahuan); ?></td>
                                <td><?php echo e($keterampilan); ?></td>
                                <td><?php echo e($nilaiAkhir); ?></td>
                                <td>
                                    <?php if($nilaiAkhir == 0): ?>
                                    -
                                    <?php else: ?>
                                    <?php echo e($predikat); ?>

                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php /**PATH F:\si_nilai_laravel\resources\views/siswa/show_nilai.blade.php ENDPATH**/ ?>
<div class="row">
    <div class="col-md-4">
        <div class="alert alert-info">
            <span>Tahun Ajaran : <?php echo e($tapel); ?></span>
            <br>
            <span>Kelas : <?php echo e($nama_kelas); ?></span>
        </div>
    </div>
</div>
<div class="card">
    <div class="card-body">
        <?php if($smt == 1): ?>
            <form id="catatan-wakel">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Nama</th>
                            <th>JK</th>
                            <th>Catatan Wali Kelas</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="tahun_ajaran" value="<?php echo e($tapel); ?>">
                        <input type="hidden" name="smt" value="<?php echo e($smt); ?>">
                        <input type="hidden" name="class_id" value="<?php echo e($classId); ?>">
                        <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <input type="hidden" name="user_id[]" value="<?php echo e($s->user_id); ?>">
                                    <?php echo e($s->nama); ?>

                                </td>
                                <td><?php echo e($s->jenis_kelamin); ?></td>
                                <td>
                                    <input type="hidden" name="status[]" value="">
                                    <textarea name="catatan[]" class="form-control" rows="5"><?php echo e($s->deskripsi); ?></textarea>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <button type="submit" class="btn btn-success mt-3 simpan">Simpan</button>
            </form>
        <?php else: ?>
            <form id="catatan-wakel">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Nama</th>
                            <th>JK</th>
                            <th>Status Kenaikan</th>
                            <th>Catatan Wali Kelas</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="tahun_ajaran" value="<?php echo e($tapel); ?>">
                        <input type="hidden" name="smt" value="<?php echo e($smt); ?>">
                        <input type="hidden" name="class_id" value="<?php echo e($classId); ?>">
                        <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <input type="hidden" name="user_id[]" value="<?php echo e($s->user_id); ?>">
                                    <?php echo e($s->nama); ?>

                                </td>
                                <td><?php echo e($s->jenis_kelamin); ?></td>
                                <td>
                                    <select name="status[]" class="form-control" style="width: 35%;">
                                        <option value="" <?php echo e($s->status_kenaikan == "" ? "selected" : ""); ?>>-</option>
                                        <option <?php echo e($s->status_kenaikan == "Ya" ? "selected" : ""); ?>>Ya</option>
                                        <option <?php echo e($s->status_kenaikan == "Tidak" ? "selected" : ""); ?>>Tidak</option>
                                    </select>
                                </td>
                                <td><textarea name="catatan[]" class="form-control" rows="5"></textarea></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <button type="submit" class="btn btn-success mt-3 simpan">Simpan</button>
            </form>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH F:\si_nilai_laravel\resources\views/guru/show_kenaikan.blade.php ENDPATH**/ ?>
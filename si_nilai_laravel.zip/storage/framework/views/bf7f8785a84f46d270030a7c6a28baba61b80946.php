<table class="table">
    <thead>
        <tr>
            <th>Kelompok</th>
            <th>Mata Pelajaran</th>
            <th>Tingkat</th>
            <th>Jurusan</th>
            <th>Nama Guru</th>
            <th>Pilih</th>
        </tr>
        <tbody>
            <?php $__currentLoopData = $mapel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($m->mapel->kelompok); ?></td>
                    <td><?php echo e($m->mapel->nama_mapel); ?></td>
                    <td><?php echo e($m->mapel->tingkat); ?></td>
                    <td><?php echo e($m->mapel->jurusan->nama_kejuruan); ?></td>
                    <td>
                        <?php if($m->guru && $m->guru->personalData): ?>
                            <?php echo e($m->guru->personalData->nama); ?>

                        <?php else: ?>
                            <em>Belum Menentukan</em> <!-- Placeholder jika guru atau personalData tidak ada -->
                        <?php endif; ?>
                    </td>
                    <td><button type="button" data-name="<?php echo e($m->mapel->nama_mapel); ?>" data-id="<?php echo e($m->class_id); ?>" data-mapel="<?php echo e($m->mapel->id); ?>" class="btn btn-info btn-sm select-guru">Pilih</button></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </thead>
</table>

<?php echo $__env->make('modals/set_mapel', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH F:\si_nilai_laravel\resources\views/mapping_guru_mapel.blade.php ENDPATH**/ ?>
<div class="row">
    <div class="col-md-4">
        <div class="alert alert-info">
            <span>Tahun Ajaran : <?php echo e($ta); ?></span>
            <br>
            <span>Kelas : <?php echo e($nama_kelas); ?></span>
        </div>
    </div>
</div>
<div class="card">
    <div class="card-body">
        <form id="rekap-absensi-siswa">
            <table class="table">
                <thead>
                    <tr>
                        <th>Nama Siswa</th>
                        <th>Sakit</th>
                        <th>Izin</th>
                        <th>Tanpa Keterangan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="class_id" value="<?php echo e($classId); ?>">
                    <input type="hidden" name="tahun_ajaran" value="<?php echo e($ta); ?>">
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><input type="hidden" name="user_id[]" value="<?php echo e($s->user_id); ?>">
                                <?php echo e($s->nama); ?>

                            </td>
                            <td>
                                <input type="text" class="form-control" name="hadir[]" style="width: 40%" value="<?php echo e($s->sakit ?? 0); ?>">
                            </td>
                            <td>
                                <input type="text" class="form-control" name="izin[]" style="width: 40%" value="<?php echo e($s->izin ?? 0); ?>">
                            </td>
                            <td>
                                <input type="text" class="form-control" name="tanpa_keterangan[]" style="width: 40%" value="<?php echo e($s->tanpa_keterangan ?? 0); ?>">
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

            <button class="btn btn-success simpan mt-3">Simpan</button>
        </form>
    </div>
</div>
<?php /**PATH F:\si_nilai_laravel\resources\views/guru/show_siswa_absen.blade.php ENDPATH**/ ?>
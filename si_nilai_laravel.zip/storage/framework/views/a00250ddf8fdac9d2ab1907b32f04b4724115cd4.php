<div class="modal fade" id="input_nilai" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
    aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="staticBackdropLabel">Input Nilai : <span id="mapel_name"></span></h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="penilaian"></form>
        </div>
    </div>
</div>
<?php /**PATH F:\si_nilai_laravel\resources\views/guru/modals/input.blade.php ENDPATH**/ ?>
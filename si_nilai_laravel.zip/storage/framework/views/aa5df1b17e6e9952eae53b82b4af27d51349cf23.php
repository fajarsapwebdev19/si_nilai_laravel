<div class="modal-body">


    <button type="button" class="btn btn-success" id="assign">Kirim</button>
</div>
<?php /**PATH F:\si_nilai_laravel\resources\views/modals/student-class.blade.php ENDPATH**/ ?>
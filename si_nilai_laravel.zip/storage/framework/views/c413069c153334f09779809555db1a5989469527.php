<?php $__env->startSection('content'); ?>
<div class="container-xxl flex-grow-1 container-p-y">
    <div class="row">
        <div class="col-xl-12 mb-4">
            <h6>Lihat Nilai</h6>
        </div>

        <div class="row">
            <div class="col-md-4">
                <form id="filter-show-nilai">
                    <div class="form-group mb-3">
                        <select name="tahun_ajaran" class="form-control">
                            <option value=""> -- Pilih -- </option>
                            <?php $__currentLoopData = $tahun; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option><?php echo e($t->tahun_ajaran); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <button type="submit" class="btn btn-success mt-3 filter">
                            Filter
                        </button>
                    </div>
                </form>
            </div>
        </div>
        <div id="show-nilai"></div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('pageTitle', 'Lihat Nilai'); ?>

<?php echo $__env->make('siswa.dash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\si_nilai_laravel\resources\views/siswa/lihat_nilai.blade.php ENDPATH**/ ?>
<div class="modal-body">
    <p class="text-center">
        Apakah Anda Yakin Ingin Menghapus Data Guru ? <?php echo e($t->personalData->nama); ?>

        <br><br>
        <?php echo csrf_field(); ?>
        <input type="hidden" id="id" value="<?php echo e($t->id); ?>">
        <button type="button" class="btn btn-success yes">
            Ya
        </button>
        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Tidak</button>
    </p>
</div>
<?php /**PATH F:\si_nilai_laravel\resources\views/modals/confirmdeleteguru.blade.php ENDPATH**/ ?>
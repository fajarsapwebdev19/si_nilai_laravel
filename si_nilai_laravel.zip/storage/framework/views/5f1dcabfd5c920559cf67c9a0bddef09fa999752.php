<div class="modal-body">
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>No</th>
                <th>NISN</th>
                <th>Nama Siswa</th>
                <th>JK</th>
                <th width="30">Pengetahuan</th>
                <th width="30">Keterampilan</th>
            </tr>
        </thead>
        <?php echo csrf_field(); ?>
        <tbody>
            <?php
            $no = 1; // Inisialisasi nomor urut
            ?>
            <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>

                    <td>
                        <input type="hidden" name="tahun_ajaran[]" value="<?php echo e($tapel); ?>">
                        <input type="hidden" name="mapel_id[]" value="<?php echo e($mapelid); ?>">
                        <input type="hidden" name="user_id[]" value="<?php echo e($s->user_id); ?>">
                        <?php echo e($no++); ?>

                    </td>
                    <td><?php echo e($s->nisn); ?></td>
                    <td><?php echo e($s->nama); ?></td>
                    <td><?php echo e($s->jenis_kelamin); ?></td>
                    <td><input type="number" name="np[]" class="form-control" value="<?php echo e($s->nilai_pengetahuan ?? 0); ?>"></td>
                    <td><input type="number" name="nk[]" class="form-control" value="<?php echo e($s->nilai_keterampilan ?? 0); ?>"></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<div class="modal-footer">
    <button type="submit" class="btn btn-success simpan">
        Simpan
    </button>
</div>
<?php /**PATH F:\si_nilai_laravel\resources\views/guru/nilai.blade.php ENDPATH**/ ?>
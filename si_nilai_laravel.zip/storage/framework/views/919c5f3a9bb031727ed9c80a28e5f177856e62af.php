<?php echo csrf_field(); ?>
<div class="modal-body">
    <input type="hidden" id="id" value="<?php echo e($mapel->id); ?>">
    <div class="form-group mb-3">
        <label for="">Kelompok</label>
        <input type="text" name="kelompok" class="form-control" value="<?php echo e($mapel->kelompok); ?>">
    </div>
    <div class="form-group mb-3">
        <label for="">Kode</label>
        <input type="text" name="kode" class="form-control" value="<?php echo e($mapel->kode); ?>">
    </div>
    <div class="form-group mb-3">
        <label for="">Nama</label>
        <input type="text" name="nama_mapel" class="form-control" value="<?php echo e($mapel->nama_mapel); ?>">
    </div>
    <div class="form-group mb-3">
        <label for="">Tingkat</label>
        <select name="tingkat" class="form-control">
            <option value="">Pilih</option>
            <option <?php echo e($mapel->tingkat == "10" ? 'selected' : ''); ?>>10</option>
            <option <?php echo e($mapel->tingkat == "11" ? 'selected' : ''); ?>>11</option>
            <option <?php echo e($mapel->tingkat == "12" ? 'selected' : ''); ?>>12</option>
        </select>
    </div>
    <div class="form-group mb-3">
        <label for="">Keahlian</label>
        <select name="jurusan" class="form-control">
            <option value="">Pilih</option>
            <?php $__currentLoopData = $k; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($j->id); ?>" <?php echo e($j->id == $mapel->jurusan_id ? 'selected' : ''); ?>><?php echo e($j->nama_kejuruan); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="form-group mb-3">
        <label for="">KKM</label>
        <input type="number" name="kkm" class="form-control" value="<?php echo e($mapel->kkm); ?>">
    </div>
    <div class="form-group mb-3">
        <label for="">Urutan</label>
        <input type="number" name="urutan" class="form-control" value="<?php echo e($mapel->urutan); ?>">
    </div>
</div>
<div class="modal-footer">
    <button type="button" class="btn btn-lg btn-success simpan">Simpan</button>
    <button type="button" class="btn btn-lg btn-danger" data-bs-dismiss="modal">Batal</button>
</div>
<?php /**PATH F:\si_nilai_laravel\resources\views/modals/update_mapel.blade.php ENDPATH**/ ?>
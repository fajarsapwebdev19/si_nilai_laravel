<div class="row">
    <div class="col-md-4 mb-4">
        <div class="alert alert-info">
            <span>Tahun Ajaran : <?php echo e($tahun); ?></span>
            <br>
            <span>Kelas : <?php echo e($nama_kelas); ?></span>
        </div>
        <div class="list-group">
            <?php $__currentLoopData = $ekskul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <button type="button" data-id="<?php echo e($e->id); ?>" data-tahun="<?php echo e($tahun); ?>" data-class="<?php echo e($class); ?>" class="list-group-item list-group-item-action nilai"><?php echo e($e->nama_ekstrakulikuler); ?></button>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <div class="col-md-8 mb-4">
        <div id="nilai-ekskul"></div>
    </div>
</div>
<?php /**PATH F:\si_nilai_laravel\resources\views/guru/show_nilai_ekskul.blade.php ENDPATH**/ ?>
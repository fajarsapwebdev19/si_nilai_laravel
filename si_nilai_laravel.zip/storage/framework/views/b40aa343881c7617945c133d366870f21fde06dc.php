<div class="mt-2">
    <h3>
        Ekskul : <?php echo e($nama_ekskul); ?>

    </h3>
</div>
<div class="card">
    <div class="card-body">
        <form id="nilai-ekskul-input">
            <table class="table">
                <thead>
                    <tr>
                        <th>Nama</th>
                        <th>JK</th>
                        <th>Nilai</th>
                        <th>Deskripsi</th>
                    </tr>
                </thead>
                <tbody>
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="class_id" value="<?php echo e($classId); ?>">
                        <input type="hidden" name="tahun" value="<?php echo e($tahun); ?>">
                        <input type="hidden" name="ekskul_id" value="<?php echo e($ekskulId); ?>">
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <input type="hidden" name="user_id[]" value="<?php echo e($s->user_id); ?>">
                                    <?php echo e($s->nama); ?>

                                </td>
                                <td><?php echo e($s->jenis_kelamin); ?></td>
                                <td>
                                    <select name="nilai[]" class="form-control" style="width: 100%;">
                                        <option value="" <?php echo e($s->nilai == "" ? "selected" : ""); ?>>-</option>
                                        <option <?php echo e($s->nilai == "A" ? "selected" : ""); ?>>A</option>
                                        <option <?php echo e($s->nilai == "B" ? "selected" : ""); ?>>B</option>
                                        <option <?php echo e($s->nilai == "C" ? "selected" : ""); ?>>C</option>
                                        <option <?php echo e($s->nilai == "D" ? "selected" : ""); ?>>D</option>
                                    </select>
                                </td>
                                <td><textarea name="deskripsi[]" class="form-control" rows="3"><?php echo e($s->deskripsi); ?></textarea></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <button type="submit" class="btn btn-success simpan mt-2">
                Simpan
            </button>
        </form>
    </div>
</div>
<?php /**PATH F:\si_nilai_laravel\resources\views/guru/input_nilai_ekskul.blade.php ENDPATH**/ ?>
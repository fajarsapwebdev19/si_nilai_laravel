<?php echo csrf_field(); ?>
<div class="row mb-3">
    <div class="col-md-2">
        <label for="">Tahun Ajaran</label>
    </div>
    <div class="col-md-10">
        <select name="tahun_ajaran" class="form-control">
            <option value="">Pilih</option>
            <?php $__currentLoopData = $th; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                {
                <option <?php echo e($p->th_aktif == $t->tahun ? 'selected' : ''); ?>> <?php echo e($t->tahun); ?></option>
                }
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
</div>
<div class="row mb-3">
    <div class="col-md-2">
        <label for="">Nama Sekolah</label>
    </div>
    <div class="col-md-10">
        <input type="text" name="nama_sekolah" class="form-control" value="<?php echo e($p->nama_sekolah); ?>">
    </div>
</div>
<div class="row mb-3">
    <div class="col-md-2">
        <label for="">NPSN</label>
    </div>
    <div class="col-md-10">
        <input type="text" name="npsn" class="form-control" value="<?php echo e($p->npsn); ?>">
    </div>
</div>
<div class="row mb-3">
    <div class="col-md-2">
        <label for="">Alamat</label>
    </div>
    <div class="col-md-10">
        <textarea name="alamat" cols="30" rows="2" class="form-control"><?php echo e($p->alamat); ?></textarea>
    </div>
</div>
<div class="row mb-3">
    <div class="col-md-2">
        <label for="">Kelurahan</label>
    </div>
    <div class="col-md-10">
        <input type="text" name="kelurahan" class="form-control" value="<?php echo e($p->kelurahan); ?>">
    </div>
</div>
<div class="row mb-3">
    <div class="col-md-2">
        <label for="">Kecamatan</label>
    </div>
    <div class="col-md-10">
        <input type="text" name="kecamatan" class="form-control" value="<?php echo e($p->kecamatan); ?>">
    </div>
</div>
<div class="row mb-3">
    <div class="col-md-2">
        <label for="">Kabupaten / Kota</label>
    </div>
    <div class="col-md-10">
        <input type="text" name="kab_kot" class="form-control" value="<?php echo e($p->kab_kot); ?>">
    </div>
</div>
<div class="row mb-3">
    <div class="col-md-2">
        <label for="">Provinsi</label>
    </div>
    <div class="col-md-10">
        <input type="text" name="provinsi" class="form-control" value="<?php echo e($p->provinsi); ?>">
    </div>
</div>
<div class="row mb-3">
    <div class="col-md-2">
        <label for="">Kode Pos</label>
    </div>
    <div class="col-md-10">
        <input type="text" name="kode_pos" class="form-control" value="<?php echo e($p->kode_pos); ?>">
    </div>
</div>
<div class="row mb-3">
    <div class="col-md-2">
        <label for="">Kepala Sekolah</label>
    </div>
    <div class="col-md-10">
        <select name="kep_id" id="" class="form-control">
            <option value="">-- Pilih Kepala Sekolah --</option>
            <?php $__currentLoopData = $ks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option <?php echo e($k->id == $p->kep_id ? 'selected' : ''); ?> value="<?php echo e($k->id); ?>">
                    <?php echo e($k->personalData->nama); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
</div>
<div class="row mb-3">
    <div class="col-md-2">
        <label for="">Logo Sekolah</label>
    </div>
    <div class="col-md-10">
        <input type="file" name="logo_sekolah" class="form-control">
    </div>
</div>
<div class="row mb-3">
    <div class="col-md-10 offset-md-2">
        <div class="d-grid gap-2">
            <button type="button" class="btn btn-success simpan">
                Simpan
            </button>
        </div>
    </div>
</div>

<?php /**PATH F:\si_nilai_laravel\resources\views/profile_smk.blade.php ENDPATH**/ ?>
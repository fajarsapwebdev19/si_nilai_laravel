<!DOCTYPE html>
<html>
<head>
    <title><?php echo e($title); ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            font-size: 12px;
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        table, th, td {
            border: 1px solid black;
        }

        th, td {
            padding: 8px;
            text-align: left;
            vertical-align: top;
        }

        th {
            background-color: #f2f2f2;
        }

        tbody tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tbody tr:nth-child(odd) {
            background-color: #ffffff;
        }

        tfoot {
            font-weight: bold;
        }

        /* Optional: Adjust column widths */
        .col-name {
            width: 25%;
        }

        .col-email {
            width: 10%;
        }

        .col-personal {
            width: 25%;
        }

        .col-guru {
            width: 25%;
        }
    </style>
</head>
<body>
    <h1><?php echo e($title); ?></h1>
    <table>
        <thead>
            <tr>
                <th class="col-name">Nama</th>
                <th class="col-email">Jenis Kelamin</th>
                <th class="col-personal">Username</th>
                <th class="col-guru">Password</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($user->nama); ?></td>
                    <td><?php echo e($user->jenis_kelamin); ?></td>
                    <td><?php echo e($user->username ?? 'Tidak Ada'); ?></td>
                    <td><?php echo e($user->real_password ?? 'Tidak Ada'); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH F:\si_nilai_laravel\resources\views/cetak/student-user.blade.php ENDPATH**/ ?>
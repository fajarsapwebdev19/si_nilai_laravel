<div class="card">
    <div class="card-body">
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card mt-2">
                <div class="card-header text-white bg-dark">
                    <?php echo e($m->judul); ?>

                    <br><br>
                    <em class="fas fa-calendar"></em> <?php echo e(date('d-m-Y H:i:s', strtotime($m->create_at))); ?> <em class="fas fa-user"></em> <?php echo e($m->user->personalData->nama); ?>

                </div>
                <div class="card-body">
                    <p class="mt-3">
                        <?php echo $m->isi; ?>

                    </p>

                    <br><br>
                    <button type="button" data-id="<?php echo e($m->id); ?>" data-title="<?php echo e($m->judul); ?>" class="btn btn-danger btn-sm hapus">
                        Hapus
                    </button>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php /**PATH F:\si_nilai_laravel\resources\views/data_pesan.blade.php ENDPATH**/ ?>
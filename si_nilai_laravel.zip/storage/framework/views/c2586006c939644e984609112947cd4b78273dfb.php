<?php $__env->startSection('content'); ?>
<div class="container-xxl flex-grow-1 container-p-y">
    <div class="row">
        <div class="col-xl-12 mb-4">
            <h6>Pengaturan <span class="fas fa-arrow-right"></span> Profil Sekolah</h6>

            <div class="message mb-4"></div>

            <div class="card">
                <div class="card-body">
                    <div class="messages"></div>
                    <form id="ubah-profile-sekolah">

                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('pageTitle', 'Profil Sekolah'); ?>

<?php echo $__env->make('dash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\si_nilai_laravel\resources\views/set_profile.blade.php ENDPATH**/ ?>
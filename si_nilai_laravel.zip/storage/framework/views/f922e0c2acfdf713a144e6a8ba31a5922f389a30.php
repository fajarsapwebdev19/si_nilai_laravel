<div class="modal-body">
    <p class="text-center">
        Apakah Anda Yakin Ingin Menghapus Data Ekskul ? <?php echo e($ekskul->nama_ekstrakulikuler); ?>

        <br><br>
        <?php echo csrf_field(); ?>
        <input type="hidden" id="id" value="<?php echo e($ekskul->id); ?>">
        <button type="button" class="btn btn-success yes">
            Ya
        </button>
        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Tidak</button>
    </p>
</div>
<?php /**PATH F:\si_nilai_laravel\resources\views/modals/confirmdeleteekskul.blade.php ENDPATH**/ ?>
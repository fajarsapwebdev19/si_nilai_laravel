<div class="row">
    <div class="col-md-4">
        <div class="alert alert-info">
            <span>Tahun Ajaran : <?php echo e($tapel); ?></span>
            <br>
            <span>Kelas : <?php echo e($nama_kelas); ?></span>
        </div>
    </div>
</div>
<div class="card">
    <div class="card-body">
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>Nama Siswa</th>
                    <th>Cetak</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($s->nama); ?></td>
                        <td>
                            <button type="button" data-user="<?php echo e($s->user_id); ?>" class="btn btn-success cover"><em class="fas fa-print"> </em> Cover</button>
                            <button type="button" class="btn btn-success profil-sekolah"><em class="fas fa-print"> </em> Profil Sekolah</button>
                            <button type="button" data-user="<?php echo e($s->user_id); ?>" class="btn btn-success identitas"><em class="fas fa-print"> </em> Identitas</button>
                            <button type="button" data-user="<?php echo e($s->user_id); ?>" data-tapel="<?php echo e($tapel); ?>" class="btn btn-success raport"><em class="fas fa-print"> </em> Raport</button>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php /**PATH F:\si_nilai_laravel\resources\views/guru/show_raport.blade.php ENDPATH**/ ?>
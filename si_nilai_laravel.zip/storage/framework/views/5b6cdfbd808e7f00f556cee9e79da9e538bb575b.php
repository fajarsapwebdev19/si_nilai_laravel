<div class="card">
    <div class="card-body">
        <table class="table mapel">
            <thead>
                <tr>
                    <th>Nama Guru</th>
                    <th>Kelas</th>
                    <th>Mata Pelajaran</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $mapel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($m->nama); ?></td>
                        <td><?php echo e($m->nama_rombel); ?></td>
                        <td><?php echo e($m->nama_mapel); ?></td>
                        <td><button type="button" data-kelas="<?php echo e($m->nama_rombel); ?>" data-id="<?php echo e($m->mapel_id); ?>" data-mapel="<?php echo e($m->nama_mapel); ?>" class="btn btn-success btn-sm nilai">Input</button></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>

<?php echo $__env->make('guru.modals/input', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH F:\si_nilai_laravel\resources\views/guru/show_mapel.blade.php ENDPATH**/ ?>
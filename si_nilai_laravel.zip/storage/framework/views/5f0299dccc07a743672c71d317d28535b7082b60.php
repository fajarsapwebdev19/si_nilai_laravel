<div class="row">
    <div class="col-md-4">
        <div class="alert alert-info">
            <span>Tahun Ajaran : <?php echo e($ta); ?></span>
            <br>
            <span>Kelas : <?php echo e($nama_kelas); ?></span>
        </div>
    </div>
</div>
<div class="card">
    <div class="card-body">
        <form id="nilai-sikap">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="class_id" value="<?php echo e($class); ?>">
            <input type="hidden" name="tahun_ajaran" value="<?php echo e($ta); ?>">
            <table class="table">
                <thead>
                    <tr>
                        <th>Nama Siswa</th>
                        <th>Spiritual</th>
                        <th>Sosial</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($s->nama); ?></td>
                            <td>
                                <input type="hidden" name="user_id[]" value="<?php echo e($s->user_id); ?>">
                                <select name="spiritual[]" id="" class="form-control">
                                    <option value="" <?php echo e($s->spiritual == "" ? "selected" : ""); ?>> - </option>
                                    <option value="A" <?php echo e($s->spiritual == "A" ? "selected" : ""); ?>> Sangat aktif dalam ibadah dan kegiatan spiritual lainnya </option>
                                    <option value="B" <?php echo e($s->spiritual == "B" ? "selected" : ""); ?>> Aktif dalam ibadah, kadang kurang konsisten </option>
                                    <option value="C" <?php echo e($s->spiritual == "C" ? "selected" : ""); ?>> Terkadang aktif dalam ibadah, perlu motivasi lebih </option>
                                    <option value="D" <?php echo e($s->spiritual == "D" ? "selected" : ""); ?>> Jarang mengikuti ibadah, perlu peningkatan motivasi </option>
                                </select>
                            </td>
                            <td>
                                <select name="sosial[]" class="form-control">
                                    <option value="" <?php echo e($s->sosial == "" ? "selected" : ""); ?>> - </option>
                                    <option value="A" <?php echo e($s->sosial == "A" ? "selected" : ""); ?>> Selalu menunjukkan sikap sopan santun </option>
                                    <option value="B" <?php echo e($s->sosial == "B" ? "selected" : ""); ?>> Biasanya sopan, kadang kurang perhatian </option>
                                    <option value="C" <?php echo e($s->sosial == "C" ? "selected" : ""); ?>> Kadang tidak sopan dalam interaksi </option>
                                    <option value="D" <?php echo e($s->sosial == "D" ? "selected" : ""); ?>> Sering menunjukkan sikap tidak sopan </option>
                                </select>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

            <button class="btn btn-success mt-3 simpan">Simpan</button>
        </form>
    </div>
</div>
<?php /**PATH F:\si_nilai_laravel\resources\views/guru/show_siswa_sikap.blade.php ENDPATH**/ ?>
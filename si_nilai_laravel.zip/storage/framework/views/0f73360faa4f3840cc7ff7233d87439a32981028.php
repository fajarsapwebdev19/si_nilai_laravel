<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rapor - <?php echo e($siswa->nama); ?> (<?php echo e($siswa->nisn); ?>)</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #fff;
            font-size: 12px;
            font-weight: 400;
        }
        .container {
            margin: 0 auto;
            padding: 20px;
            box-sizing: border-box;
            background-color: #fff;
        }

        .text-left {
            text-align: left;
        }

        h3 {
            text-align: center;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid #000;
        }
        th, td {
            padding: 4px;
            text-align: center;
        }
        .section-title {
            text-align: left;
            margin-bottom: 8px;
            font-weight: bold;
        }
        .details {
            margin-bottom: 10px;
        }
        .details table td {
            text-align: left;
            border: none;
            padding: 2px;
        }
        .nilai thead{
            background-color: #eaeaea;
        }

        .no-border {
            border: none !important;
        }

        #tanda-tangan{
            width: 100% !important;
        }

        #tanda-tangan, thead{
            border: none;
        }

        #tanda-tangan td {
            width: 50%;
            vertical-align: top;
            border: none;
        }

        .label {
            width: 25%;
            text-align: left;
        }
        .colon {
            width: 2%;
            text-align: center;
        }
        .value {
            width: 40%;
            text-align: left;
        }
        .garis{
            border: 1px solid #000;
        }

        .page-break {
            page-break-after: always;
        }

        .naik{
            text-decoration: line-through;
        }
    </style>
</head>
<body>
    <div class="container">
        
        <div class="details">
            <table class="no-border">
                <tr>
                    <td class="label"><strong>Nama Peserta Didik</strong></td>
                    <td class="colon">:</td>
                    <td class="value"><?php echo e($siswa->nama); ?></td>
                    <td class="label"><strong>Tahun Ajaran</strong></td>
                    <td class="colon">:</td>
                    <td class="value"><?php echo e($tahun_ajaran); ?></td>
                </tr>
                <tr>
                    <td class="label"><strong>NISN</strong></td>
                    <td class="colon">:</td>
                    <td class="value"><?php echo e($siswa->nisn); ?></td>
                    <td class="label"><strong>Semester</strong></td>
                    <td class="colon">:</td>
                    <td class="value"><?php echo e($smt->semester); ?> (<?php echo e($semester); ?>)</td>
                </tr>
                <tr>
                    <td class="label"><strong>Nama Sekolah</strong></td>
                    <td class="colon">:</td>
                    <td class="value"><?php echo e($sekolah->nama_sekolah); ?></td>
                    <td class="label"><strong>Kelas</strong></td>
                    <td class="colon">:</td>
                    <td class="value"><?php echo e($nama_kelas); ?></td>
                </tr>
                <tr>
                    <td class="label"><strong>NPSN</strong></td>
                    <td class="colon">:</td>
                    <td class="value"><?php echo e($sekolah->npsn); ?></td>
                    <td class="label"><strong>Program Keahlian</strong></td>
                    <td class="colon">:</td>
                    <td class="value"><?php echo e($siswa->nama_kejuruan); ?></td>
                </tr>
            </table>

            <div class="garis"></div>

            <h3>Laporan Hasil Belajar</h3>
        </div>

        

        
        <p class="section-title"><b>A. Nilai Akademik</b></p>
        <table class="nilai">
            <thead>
                <tr>
                    <th rowspan="2">No</th>
                    <th rowspan="2">Mata Pelajaran</th>
                    <th rowspan="2">KKM</th>
                    <th colspan="2">Penilaian</th>
                    <th rowspan="2">Nilai Akhir</th>
                    <th rowspan="2">Predikat</th>
                </tr>
                <tr>
                    <th>Pengetahuan</th>
                    <th>Keterampilan</th>
                </tr>
            </thead>
            <tbody>
                
                <?php if($kel_a): ?>
                    <tr>
                        <th colspan="7" class="text-left">A. Muatan Nasional</th>
                    </tr>
                <?php endif; ?>
                <?php $__currentLoopData = $kel_a; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $ka): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $nilaiMapel = $nilai->where('mapel_id', $ka->id)->first();
                        $pengetahuan = $nilaiMapel ? $nilaiMapel->nilai_pengetahuan : 0;
                        $keterampilan = $nilaiMapel ? $nilaiMapel->nilai_keterampilan : 0;
                        $nilaiAkhir = ($pengetahuan + $keterampilan) / 2;
                        $predikat = $nilaiAkhir >= $ka->kkm + 20 ? 'A+' :
                                    ($nilaiAkhir >= $ka->kkm + 10 ? 'A' :
                                    ($nilaiAkhir >= $ka->kkm ? 'B' :
                                    ($nilaiAkhir >= $ka->kkm - 10 ? 'C' : 'D')));
                    ?>
                    <tr>
                        <th><?php echo e($ka->urutan); ?></th>
                        <td class="text-left"><?php echo e($ka->nama_mapel); ?></td>
                        <td><?php echo e($ka->kkm); ?></td>
                        <td><?php echo e($pengetahuan); ?></td>
                        <td><?php echo e($keterampilan); ?></td>
                        <td><?php echo e(number_format($nilaiAkhir, 2)); ?></td>
                        <td><?php echo e($predikat); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                

                
                <?php if($kel_b): ?>
                    <tr>
                        <th colspan="7" class="text-left">B. Muatan Kewilayahan</th>
                    </tr>
                <?php endif; ?>
                <?php $__currentLoopData = $kel_b; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $kb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $nilaiMapel = $nilai->where('mapel_id', $kb->id)->first();
                        $pengetahuan = $nilaiMapel ? $nilaiMapel->nilai_pengetahuan : 0;
                        $keterampilan = $nilaiMapel ? $nilaiMapel->nilai_keterampilan : 0;
                        $nilaiAkhir = ($pengetahuan + $keterampilan) / 2;
                        $predikat = $nilaiAkhir >= $kb->kkm + 20 ? 'A+' :
                                    ($nilaiAkhir >= $kb->kkm + 10 ? 'A' :
                                    ($nilaiAkhir >= $kb->kkm ? 'B' :
                                    ($nilaiAkhir >= $kb->kkm - 10 ? 'C' : 'D')));
                    ?>
                    <tr>
                        <th><?php echo e($kb->urutan); ?></th>
                        <td class="text-left"><?php echo e($kb->nama_mapel); ?></td>
                        <td><?php echo e($kb->kkm); ?></td>
                        <td><?php echo e($pengetahuan); ?></td>
                        <td><?php echo e($keterampilan); ?></td>
                        <td><?php echo e(number_format($nilaiAkhir, 2)); ?></td>
                        <td><?php echo e($predikat); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                

                
                <?php if($kel_c1): ?>
                    <tr>
                        <th colspan="7" class="text-left">C1. Dasar Bidang Keahlian</th>
                    </tr>
                <?php endif; ?>
                <?php $__currentLoopData = $kel_c1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $kc1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $nilaiMapel = $nilai->where('mapel_id', $kc1->id)->first();
                        $pengetahuan = $nilaiMapel ? $nilaiMapel->nilai_pengetahuan : 0;
                        $keterampilan = $nilaiMapel ? $nilaiMapel->nilai_keterampilan : 0;
                        $nilaiAkhir = ($pengetahuan + $keterampilan) / 2;
                        $predikat = $nilaiAkhir >= $kc1->kkm + 20 ? 'A+' :
                                    ($nilaiAkhir >= $kc1->kkm + 10 ? 'A' :
                                    ($nilaiAkhir >= $kc1->kkm ? 'B' :
                                    ($nilaiAkhir >= $kc1->kkm - 10 ? 'C' : 'D')));
                    ?>
                    <tr>
                        <th><?php echo e($kc1->urutan); ?></th>
                        <td class="text-left"><?php echo e($kc1->nama_mapel); ?></td>
                        <td><?php echo e($kc1->kkm); ?></td>
                        <td><?php echo e($pengetahuan); ?></td>
                        <td><?php echo e($keterampilan); ?></td>
                        <td><?php echo e(number_format($nilaiAkhir, 2)); ?></td>
                        <td><?php echo e($predikat); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                

                
                <?php if($kel_c2): ?>
                    <tr>
                        <th colspan="7" class="text-left">C2. Dasar Program Keahlian</th>
                    </tr>
                <?php endif; ?>
                <?php $__currentLoopData = $kel_c2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $kc2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $nilaiMapel = $nilai->where('mapel_id', $kc2->id)->first();
                        $pengetahuan = $nilaiMapel ? $nilaiMapel->nilai_pengetahuan : 0;
                        $keterampilan = $nilaiMapel ? $nilaiMapel->nilai_keterampilan : 0;
                        $nilaiAkhir = ($pengetahuan + $keterampilan) / 2;
                        $predikat = $nilaiAkhir >= $kc2->kkm + 20 ? 'A+' :
                                    ($nilaiAkhir >= $kc2->kkm + 10 ? 'A' :
                                    ($nilaiAkhir >= $kc2->kkm ? 'B' :
                                    ($nilaiAkhir >= $kc2->kkm - 10 ? 'C' : 'D')));
                    ?>
                    <tr>
                        <th><?php echo e($kc2->urutan); ?></th>
                        <td class="text-left"><?php echo e($kc2->nama_mapel); ?></td>
                        <td><?php echo e($kc2->kkm); ?></td>
                        <td><?php echo e($pengetahuan); ?></td>
                        <td><?php echo e($keterampilan); ?></td>
                        <td><?php echo e(number_format($nilaiAkhir, 2)); ?></td>
                        <td><?php echo e($predikat); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                

                
                <?php if($kel_c3): ?>
                    <tr>
                        <th colspan="7" class="text-left">C3. Kompetensi Keahlian</th>
                    </tr>
                <?php endif; ?>
                <?php $__currentLoopData = $kel_c3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $kc3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $nilaiMapel = $nilai->where('mapel_id', $kc3->id)->first();
                        $pengetahuan = $nilaiMapel ? $nilaiMapel->nilai_pengetahuan : 0;
                        $keterampilan = $nilaiMapel ? $nilaiMapel->nilai_keterampilan : 0;
                        $nilaiAkhir = ($pengetahuan + $keterampilan) / 2;
                        $predikat = $nilaiAkhir >= $kc3->kkm + 20 ? 'A+' :
                                    ($nilaiAkhir >= $kc3->kkm + 10 ? 'A' :
                                    ($nilaiAkhir >= $kc3->kkm ? 'B' :
                                    ($nilaiAkhir >= $kc3->kkm - 10 ? 'C' : 'D')));
                    ?>
                    <tr>
                        <th><?php echo e($kc3->urutan); ?></th>
                        <td class="text-left"><?php echo e($kc3->nama_mapel); ?></td>
                        <td><?php echo e($kc3->kkm); ?></td>
                        <td><?php echo e($pengetahuan); ?></td>
                        <td><?php echo e($keterampilan); ?></td>
                        <td><?php echo e(number_format($nilaiAkhir, 2)); ?></td>
                        <td><?php echo e($predikat); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </tbody>
        </table>

        

        
        <p class="section-title">B. Nilai Sikap</p>
        <table>
            <thead>
                <tr>
                    <th width="10">No</th>
                    <th width="150">Aspek Sikap</th>
                    <th width="90">Predikat</th>
                    <th>Deskripsi</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>1</td>
                    <td>Sikap Spiritual</td>
                    <td><?php echo e($ns->spiritual ?? "-"); ?></td>
                    <td>
                        <?php if($ns): ?>
                            <?php if($ns->spiritual == "A"): ?>
                                Sangat aktif dalam ibadah dan kegiatan spiritual lainnya
                            <?php elseif($ns->spiritual == "B"): ?>
                                Aktif dalam ibadah, kadang kurang konsisten
                            <?php elseif($ns->spiritual == "C"): ?>
                                Terkadang aktif dalam ibadah, perlu motivasi lebih
                            <?php elseif($ns->spiritual == "D"): ?>
                                Jarang mengikuti ibadah, perlu peningkatan motivasi
                            <?php elseif($ns->spiritual == ""): ?>
                                -
                            <?php else: ?>
                                -
                            <?php endif; ?>
                        <?php else: ?>
                            -
                        <?php endif; ?>
                    </td>
                </tr>
                <tr>
                    <td>2</td>
                    <td>Sikap Sosial</td>
                    <td><?php echo e($ns->sosial ?? "-"); ?></td>
                    <td>
                        <?php if($ns): ?>
                            <?php if($ns->sosial == "A"): ?>
                                Selalu menunjukkan sikap sopan santun
                            <?php elseif($ns->sosial == "B"): ?>
                                Biasanya sopan, kadang kurang perhatian
                            <?php elseif($ns->sosial == "C"): ?>
                                Kadang tidak sopan dalam interaksi
                            <?php elseif($ns->sosial == "D"): ?>
                                Sering menunjukkan sikap tidak sopan
                            <?php endif; ?>
                        <?php else: ?>
                            -
                        <?php endif; ?>
                    </td>
                </tr>
            </tbody>
        </table>

        

        <div class="page-break"></div>

        
        <p class="section-title">C. Catatan Akademis</p>
        <table>
            <tr>
                <td class="text-left">
                    <?php echo e($kn->deskripsi ?? ""); ?>

                </td>
            </tr>
        </table>

        

        
        <p class="section-title">D. Ekstrakulikuller</p>
        <table>
            <thead>
                <tr>
                    <th width="50">No</th>
                    <th width="190">Kegiatan Eksktrakulikuller</th>
                    <th width="50">Predikat</th>
                    <th>Deskripsi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $e; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $eks): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($ne): ?>

                        <?php
                            $nilai_ekskul = $ne->where('ekskul_id', $eks->id)->first();
                            $nilai = $nilai_ekskul ? $nilai_ekskul->nilai : '-';
                            $deskripsi = $nilai_ekskul ? $nilai_ekskul->deskripsi : '-';
                        ?>
                        <tr>
                            <td><?php echo e($index + 1); ?></td>
                            <td><?php echo e($eks->nama_ekstrakulikuler); ?></td>
                            <td><?php echo e($nilai); ?></td>
                            <td><?php echo e($deskripsi); ?></td>
                        </tr>
                    <?php else: ?>
                    <tr>
                        <td><?php echo e($index + 1); ?></td>
                        <td><?php echo e($eks->nama_ekstrakulikuler); ?></td>
                        <td>-</td>
                        <td>-</td>
                    </tr>
                    <?php endif; ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        

        
        <p class="section-title">E. Ketidakhadiran</p>
        <table style="width: 50%">
            <thead>
                <tr>
                    <td width="150">
                        Sakit
                    </td>
                    <td width="10">
                        :
                    </td>
                    <td class="200">
                        <strong><?php echo e($kt->sakit ?? "-"); ?> Hari</strong>
                    </td>
                </tr>
                <tr>
                    <td width="150">
                        Izin
                    </td>
                    <td width="10">
                        :
                    </td>
                    <td class="200">
                        <strong><?php echo e($kt->izin ?? "-"); ?> Hari</strong>
                    </td>
                </tr>
                <tr>
                    <td width="150">
                        Tanpa Keterangan
                    </td>
                    <td width="10">
                        :
                    </td>
                    <td class="200">
                        <strong><?php echo e($kt->tanpa_keterangan ?? "-"); ?> Hari</strong>
                    </td>
                </tr>
            </thead>
        </table>
        

        
        <?php if($semester == 2): ?>
            <p class="section-title">F. Kenaikan Kelas</p>
            <table>
                <thead>
                    <tr>
                        <td>
                            <span class="<?php echo e($kn->status_kenaikan == "Tidak" ? "naik" : ""); ?>">NAIK</span> / <span class="<?php echo e($kn->status_kenaikan == "Ya" ? "naik" : ""); ?>">TIDAK NAIK</span>
                        </td>
                    </tr>
                </thead>
            </table>
        <?php endif; ?>
        

        
        <div class="section-title"></div>
        <br><br>
        <table id="tanda-tangan">
            <thead>
                <tr>
                    <td>
                        <span>Mengetahui,</span>
                        <br>
                        <span>Orang Tua/Wali</span>
                        <br><br><br><br><br><br><br>
                        <strong><?php echo e($siswa->nama_ayah ?? "______________________________"); ?></strong>
                    </td>
                    <td>
                        <span><?php echo e($sekolah->kab_kot); ?>, <?php echo e(date('d-m-Y')); ?></span>
                        <br>
                        <span>Wali Kelas</span>
                        <br><br><br><br><br><br><br>
                        <strong><?php echo e($w->nama ?? "______________________________"); ?></strong>
                    </td>
                </tr>
                <tr>
                    <td colspan="2" class="text-center">
                        <span>Mengetahui, </span>
                        <br>
                        Kepala Sekolah <?php echo e($sekolah->nama_sekolah); ?>

                        <br><br><br><br><br><br><br>
                        <strong><?php echo e($ks->nama ?? "______________________________"); ?></strong>
                    </td>
                </tr>
            </thead>
        </table>
        
    </div>
</body>
</html>
<?php /**PATH F:\si_nilai_laravel\resources\views/cetak/raport_siswa.blade.php ENDPATH**/ ?>
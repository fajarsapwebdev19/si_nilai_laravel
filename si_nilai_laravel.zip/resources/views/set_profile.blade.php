@extends('dash')
@section('content')
<div class="container-xxl flex-grow-1 container-p-y">
    <div class="row">
        <div class="col-xl-12 mb-4">
            <h6>Pengaturan <span class="fas fa-arrow-right"></span> Profil Sekolah</h6>

            <div class="message mb-4"></div>

            <div class="card">
                <div class="card-body">
                    <div class="messages"></div>
                    <form id="ubah-profile-sekolah">

                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
@section('pageTitle', 'Profil Sekolah')
